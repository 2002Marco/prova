//classe figlia che rappresenta il corpo celeste pianeta, caratterizzata oltre agli attributi ereditati da un array list di lune che gli orbitano attorno

package it.unibs.pa;

import java.util.ArrayList;

public  class Pianeta extends CorpoCeleste {
	
	ArrayList <Luna> lune;

	public Pianeta(String codiceUnivoco, Coordinate posizione, double massa) {
		super(codiceUnivoco, posizione, massa);
		lune = new ArrayList <Luna>();
	}
	
	
	
	public ArrayList<Luna> getLune() {
		return lune;
	}


	public  void aggiungiLuna(String codiceUnivoco, Coordinate posizione, double massa, Pianeta pianeta) {		//metodo per aggiungere una luna
		lune.add(new Luna(codiceUnivoco, posizione, massa, pianeta));
	}
	
	
	
	public void rimuoviLuna(Luna l) {		//metodo per rimuovere una luna dando in input la luna che si vuole rimuovere 
		int i =0;
		for ( i = 0; i < this.lune.size(); i++) {
			if(lune.get(i).getCodiceUnivoco() == l.getCodiceUnivoco())		//trova la posizione della luna che devo rimuovere (controllando che abbiano lo stesso codice univoco)
				break;
		}
		
		lune.remove(i);  		//utilizzo del metodo remove dell'arraylist
		
	}
	
	public void stampaLune() {			//stampa le lune orbitanti intorno a un pianeta
		if (this.lune.isEmpty()) {		//se non orbita nessuna luna
			System.out.println("Il pianeta non possiede lune ");
		}
		
		else {		
		System.out.println("La lista delle lune che ruotano intorno a questo pianeta: ");
		for (int i = 0; i < lune.size(); i++ ) 
			System.out.println(i+1 +")" + lune.get(i).getCodiceUnivoco());
		}
	}	
}