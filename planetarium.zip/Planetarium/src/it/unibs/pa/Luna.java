//classe figlia che rappresenta il corpo celeste luna, caratterizzata oltre agli attributi ereditati un Pianeta a cui orbita intorno 

package it.unibs.pa;

public class Luna extends CorpoCeleste {
	
	private Pianeta pianeta;

	public Luna(String codiceUnivoco, Coordinate posizione, double massa, Pianeta pianeta) {
		super(codiceUnivoco, posizione, massa);
		this.pianeta = pianeta;
	}
		
	public Pianeta getPianeta() {
		return pianeta;
	}
	
	public String toString() {
		return String.format("Codice univoco: %s\nMassa: %f\nPosizione:" +  this.getPosizione().toString() + "\nPianeta madre: %s" , this.getCodiceUnivoco(), this.getMassa(),
				this.pianeta.getCodiceUnivoco());
	}
	
	public String percorso(SistemaStellare ss) {			//ritorna il percorso Stella>Pianeta>Luna 																
		return ss.getStella().getCodiceUnivoco() +" > " + this.getPianeta().getCodiceUnivoco() + " > " + this.getCodiceUnivoco();
	}
	
}