//la classe corpoceleste � la classe padre delle classi Luna, Pianeta, Stella

package it.unibs.pa;

public class CorpoCeleste {
	
	private String codiceUnivoco;
	private Coordinate posizione;
	private double massa;
	
	public CorpoCeleste(String codiceUnivoco, Coordinate posizione, double massa) {
		this.codiceUnivoco = codiceUnivoco;													
		this.posizione = posizione;
		this.massa = massa;
	}
	
	@Override
	public String toString() {
		return String.format("Codice univoco: %s\nMassa: %f\nPosizione:" + posizione.toString(), this.codiceUnivoco, this.massa);
	}

	public String getCodiceUnivoco() {				
		return codiceUnivoco;
	}

	public Coordinate getPosizione() {
		return posizione;
	}

	public double getMassa() {
		return massa;
	}
}