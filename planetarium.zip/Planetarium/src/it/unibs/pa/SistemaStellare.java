//classe che rappresenta il Sistema Solare e che ne aggrega i diversi corpi, ha come attributi una stella, un array list di pianeti e di lune

package it.unibs.pa;

import java.util.ArrayList;

public class SistemaStellare {
	
	private Stella stella;
	private ArrayList <Pianeta> pianeti;
	private ArrayList <Luna> lune;

	
	public SistemaStellare(Stella stella) {
		this.pianeti = new ArrayList<Pianeta>();
		this.lune = new ArrayList <Luna>();
		this.stella = stella;
	}
	
	public boolean codice(String codice) {			//controlla se il codice univoco � gi� stato scelto per un altro corpo
		
		if(this.stella.getCodiceUnivoco().equals(codice))		//controlla se il codice appartiene gi� alla stella	
			return true;

		for(int i = 0; i<lune.size(); i++)
			if (lune.get(i).getCodiceUnivoco().equals(codice))	//controlla se il codice appartiene gi� a una luna
				return true;
		for(int i=0; i<pianeti.size(); i++)
			if (pianeti.get(i).getCodiceUnivoco().equals(codice))		//controlla se il codice appartiene gi� a un pianeta
				return true;
		
		return false;
	}
	
	
	
	public Stella getStella() {
		return this.stella;
	}
	
	public ArrayList <Pianeta> getPianeti(){
		return this.pianeti;
	}
	
	public ArrayList <Luna> getLune(){
		return this.lune;
	}
	
	public void stampaPianeti(){		//stampa la lista dei pianeti "scoperti"
		
		System.out.println("La lista dei pianeti scoperti in questo sistema stellare: \n");
		for (int i = 0; i < pianeti.size(); i++ ) {
			System.out.println(i+1 +")" + pianeti.get(i).getCodiceUnivoco());
			System.out.println();
			
		}
	}
	
	public void stampaLune(){			//stampa la lista delle lune "scoperte"
		
		System.out.println("La lista delle lune scoperte in questo sistema stellare: ");
		for (int i = 0; i < lune.size(); i++ ) {
			System.out.println(i+1 +")" + lune.get(i).getCodiceUnivoco());
			
		}
	}	
	
	public void stampaCorpi() {		//stampa la lista dei tutti i corpi del sistema
		int i = 0;
		
		
		System.out.println("1)" + stella.getCodiceUnivoco());
		
		for (i = 0; i < pianeti.size(); i++ ) 
			System.out.println(i+2 +")" + pianeti.get(i).getCodiceUnivoco());
		
		for ( int k = 0; k < lune.size(); k++ ) 
			System.out.println(i+2 +")" + lune.get(k).getCodiceUnivoco());
		
		
	}
		
	
	public Coordinate centroDiMassa () {
		
		Coordinate cM = new Coordinate(0.00, 0.00);			//crea una coordinata dove verr� salvata la coordinata del centro di massa
		double sommaMasse = stella.getMassa();				//salver� la somma delle masse
		Coordinate coordPesate = new Coordinate (0.00, 0.00);		//salver� la somma pesata di tutte le coordinate

		for (int i =0; i< pianeti.size(); i++) {		//calcola le coordinate pesate dei pianeti e la massa totale dei pianeti
			sommaMasse += pianeti.get(i).getMassa();
			coordPesate.setX( coordPesate.getX() + pianeti.get(i).getMassa()*pianeti.get(i).getPosizione().getX());		
			coordPesate.setY( coordPesate.getY() + pianeti.get(i).getMassa()*pianeti.get(i).getPosizione().getY());
		}
		for (int i = 0; i< lune.size(); i++) {		//calcola le coordinate pesate delle lune aggiungendole a quelle dei pianeti e la massa totale aggiungendo le lune
			sommaMasse += lune.get(i).getMassa();
			coordPesate.setX( coordPesate.getX() + lune.get(i).getMassa()*lune.get(i).getPosizione().getX());
			coordPesate.setY( coordPesate.getY() + lune.get(i).getMassa()*lune.get(i).getPosizione().getY());
		}
		System.out.println("Somma delle masse: " + sommaMasse);
		System.out.println("Somma pesata delle posizioni: " + coordPesate.toString());
		
		cM.setX(coordPesate.getX()/ sommaMasse);		//calcolo coordinate centro di massa
		cM.setY(coordPesate.getY()/ sommaMasse);
		
		return cM;
	}
	
	public void aggiungiPianeta(String codiceUnivoco, Coordinate posizione, double massa) {		//aggiunge un pianeta
	
		pianeti.add(new Pianeta(codiceUnivoco, posizione, massa));
		
	}
	public void aggiungiLuna (String codiceUnivoco, Coordinate posizione, double massa, Pianeta pianeta) {	//aggiunge una luna
		lune.add(new Luna(codiceUnivoco, posizione, massa, pianeta));
		
		
	}
	
	public void rimuoviPianeta(int i) {		//rimuove un pianeta, la funzione prende in input la posizione del pianeta da rimuovere (i) 
		
		if (!pianeti.get(i).getLune().isEmpty()) { 		//se il pianeta ha lune le rimuove dal sistema
			for(int j = 0; j<this.lune.size(); j++) {		//ciclo for per scorrere le lune dell'arraylist
				for (int k = 0; k<pianeti.get(i).getLune().size(); k++) {		//ciclo per scorrere le lune del pianeta da rmuovere
					if (lune.get(j).getCodiceUnivoco() == pianeti.get(i).getLune().get(k).getCodiceUnivoco());			//se il codice della luna dell'arraylist di lune corrisponde a quello della luna del pianeta da rimuovere, allora viene rimossa
						lune.remove(j);		
				}
			}
			
		}
		pianeti.remove(i);		//rimuove il pianeta
		
		
	}
	
	public void rimuoviLuna(int i) {		//rimuove la luna data la posizione nella lista di lune
		lune.remove(i);
	}
	
	public void ricerca(String corpoDaCercare) {		//funzione che serve per la ricerca di un corpo dato il codice univoco 
		
		if (stella.getCodiceUnivoco().equals(corpoDaCercare)) {		//controlla il codice univoco della stella 
			System.out.println("La stella " + stella.getCodiceUnivoco() + " � presente");
			return;
		}
		
		for(int i = 0; i < lune.size(); i++) {		//controlla il codice delle lune e stampa il pianeta attorno al quale orbita
			if (lune.get(i).getCodiceUnivoco().equals(corpoDaCercare)) {
				System.out.println("La luna " + lune.get(i).getCodiceUnivoco() +" � presente, ruota attorna ad: " + lune.get(i).getPianeta().getCodiceUnivoco());
				return;
			}
		}	
		for (int i = 0; i< pianeti.size(); i++) {		//controlla il codice dei pianeti
			if (pianeti.get(i).getCodiceUnivoco().equals(corpoDaCercare)) {
				System.out.println("Il pianeta " + pianeti.get(i).getCodiceUnivoco()+ " � presente");
				return;
			}
		}
		System.out.println("Corpo non trovato!");		//se non viene trovato
		
	}
	
	public void informazioni(int i) {		//funzione che preso in input la posizione nella lista del corpo stampa le informazioni
		
		if(i == 1)		//se la posizione scelta � 1, allora si tratta per forza della stella perch� sono elencate con l'ordine: stella>pianeti>lune
			System.out.println(stella.toString());
		
		else if (i > pianeti.size()+1) {		//se la posozione scelta � maggiore del numero di pianeti pi� la stella, allora tolgo il numero di pianeti per trovare la posizione della stella nella lista 
			i = i - pianeti.size() - 1;
			System.out.println(lune.get(i-1).toString());	
			System.out.println(lune.get(i-1).percorso(this));
			
		}
		else {			//altrimenti si tratta di un pianeta 
			System.out.println(pianeti.get(i-2).toString());  
			pianeti.get(i-2).stampaLune();
		}
		
	}
}
	
