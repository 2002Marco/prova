//classe che rappresenta un punto nel piano identificato da una x e una y

package it.unibs.pa;

public class Coordinate {
	
	private double x;
	private double y;
	
	
	public Coordinate(double x, double y) {
		this.x = x;
		this.y = y;
	}


	public double getX() {				
		return x;
	}


	public void setX(double x) {
		this.x = x;
	}


	public double getY() {
		return y;
	}


	public void setY(double y) {
		this.y = y;
	}
	
	public String toString() {									//stampa le coordinate
		return String.format("(%.2f,%.2f)", x, y);
	}

}