//classe figlia che rappresenta il corpo celeste stella
//la stella ha coordinate 0,0

package it.unibs.pa;

public class Stella extends CorpoCeleste {

	public Stella(String codiceUnivoco, Coordinate posizione, double massa) {
		super(codiceUnivoco, posizione, massa);
	}
}