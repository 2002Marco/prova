package it.unibs.pa;

import java.util.ArrayList;

import it.unibs.fp.mylib.InputDati;
import it.unibs.fp.mylib.MyMenu;

public class Main {

	public static void main(String[] args) {
	
		int scelta = 0;		//variabile che serve per la scelta dell'utente nel men�
		String [] voci = {"Aggiungi Pianeta", "Aggiungi Luna", "Rimuovi Pianeta", "Rimuovi Luna", "Informazioni",		
				"Ricerca Corpo Celeste", "Calcolo del CDM"};		//voci del men�
		MyMenu menu = new MyMenu("", voci);
		
		System.out.println("Benvenuto nel planetarium!");		
		System.out.println("Per prima cosa inserisci una stella che sar� il centro del sistema");
		InputDati.premiInvioPerContinuare();
		
		Stella stella = creaStella();			//invoca la funzione per creare la stella del sistema
		SistemaStellare ss = new SistemaStellare(stella);	//crea il sistema stellare  
		
		do {		
			
			scelta = menu.scegli();
			switch(scelta) {
			case 1: 
				aggiungiPianeta(ss);		
				break;
			case 2:
				aggiungiLuna(ss);
				break;
			case 3:
				rimuoviPianeta(ss);
				break;
			case 4:
				rimuoviLuna(ss);
				break;
			case 5:
				System.out.println("\n");
				informazioni(ss);
				break;
			case 6:
				String corpoDaCercare = InputDati.leggiStringaNonVuota("Inserisci il corpo celeste da cercare:");
				ss.ricerca(corpoDaCercare);
				InputDati.premiInvioPerContinuare();
				break;
			case 7:
				System.out.println("CDM: " + ss.centroDiMassa().toString());		//stampa il centro di massa
				InputDati.premiInvioPerContinuare();
			}
			
		}while(scelta != 0);		//scegliere 0 per uscire
		
	}
	public static Stella creaStella() {		
		
		String codiceUnivoco = InputDati.leggiStringaNonVuota("Inserisci il codice della stella: ");
		double massa = InputDati.leggiDoubleConMinimo("Inserisci la massa della stella: ", 1);
		
		return new Stella(codiceUnivoco, new Coordinate(0, 0), massa);		//impostiamo le coordinate 0,0 
	}
	
	public static void aggiungiPianeta(SistemaStellare ss) {		//funzione per l'aggiunta di un pianeta
		
		String codiceUnivoco;
		
		do {
			 codiceUnivoco = InputDati.leggiStringaNonVuota("Inserisci il codice del pianeta:");
			 if(ss.codice(codiceUnivoco))
				 System.out.println("Codice gi� esistente\n");
		}while(ss.codice(codiceUnivoco));		//controlla che il codice univoco del pianeta da aggiungere non sia gi� presente nel sistema
		
		double x = InputDati.leggiDouble("Inserisci la x : ");		//chiede all'utente le informazioni del pianeta
		double y = InputDati.leggiDouble("Inserisci la y : ");
		Coordinate posizione = new Coordinate(x,y);
		double massa = InputDati.leggiDoubleConMinimo("Inserisci la massa: ", 1);
		ss.aggiungiPianeta(codiceUnivoco, posizione, massa);
		
	}
	public static void aggiungiLuna (SistemaStellare ss) {		//funzione per l'aggiunta di una luna
		
		String codiceUnivoco;
		ArrayList <Pianeta> pianeti = ss.getPianeti();		//lista dei pianeti
		int scelta = 0;
		
		if (pianeti.isEmpty()){			//se non essitono pianeti, non � possibile aggiungere una luna
			System.out.println("\nNon ci sono pianeti!");
			InputDati.premiInvioPerContinuare();
			return;
		}
		else {		//altrimenti stampa la lista dei pianeti
			ss.stampaPianeti();
			scelta = InputDati.leggiIntero("Scegli il paineta:", 1, pianeti.size());	//l'utente sceglie il pianeta a cui associare la nuova luna
		}
		do {		
			codiceUnivoco = InputDati.leggiStringaNonVuota("Inserisci il codice della luna:");		
			if(ss.codice(codiceUnivoco))
				System.out.println("Codice gi� esistente");
		}while(ss.codice(codiceUnivoco)); 		//controlla che il codice univoco della luna da aggiungere non sia gi� presente nel sistema
		
		
		double x = InputDati.leggiDouble("Inserisci la x : ");				//chiede all'utente le informazioni della luna
		double y = InputDati.leggiDouble("Inserisci la y : ");
		Coordinate posizione = new Coordinate(x,y);
		int massa = InputDati.leggiInteroConMinimo("Inserisci la massa: ", 1);
		
		
		pianeti.get(scelta-1).aggiungiLuna(codiceUnivoco, posizione, massa, pianeti.get(scelta-1));		//prende il pianeta a cui la luna deve essere aggiunta e chiama la funzione aggiungiLuna su quel pianeta
		ss.aggiungiLuna(codiceUnivoco, posizione, massa, pianeti.get(scelta-1));		//aggiunge la luna nell'arraylist di tutte le lune presenti nel sistema
		
	}
	
	public static void rimuoviPianeta(SistemaStellare ss) {		//funzione per la rimozione di un pianeta
		ArrayList <Pianeta> pianeti = ss.getPianeti();		//prende la lista dei pianeti
		int scelta = 0;
		
		if (pianeti.isEmpty()){		//se non ci sono pianeti da rimuove, non � possibile rimuovere nessun pianeta
			System.out.println("Non ci sono pianeti!");
			return;
		}
		else {		//stampa la lista e prende la scelta dell'utente
			ss.stampaPianeti();
			scelta = InputDati.leggiIntero("Scegli il pianeta:", 1, pianeti.size());
		}
		
		ss.rimuoviPianeta(scelta-1);		//rimuove il pianeta
	}
	
	public static void rimuoviLuna(SistemaStellare ss) {		//funzione per la rimozione di una luna
		ArrayList <Luna> lune = ss.getLune();		//prende la lista delle lune
		int scelta = 0;
		
		if(lune.isEmpty()) {		//se non ci sono lune da rimuove, non � possibile rimuovere nessuna luna
			System.out.println("Non ci sono lune");
			return;
		}
		else {		//stampa la lista e prende la scelta dell'utente	
			ss.stampaLune();
			scelta = InputDati.leggiIntero("Scegli la luna:", 1, lune.size() ) -1;
	
		}
		lune.get(scelta).getPianeta().rimuoviLuna(lune.get(scelta));		//presa la luna da rimuovere, prendiamo il suo pianeta e chiamiamo la funzione rimuoviluna sulla scelta
		ss.rimuoviLuna(scelta);		//rimozione
	}
	
	public static void informazioni(SistemaStellare ss) {		//funzione che stampa tutti i corpi e chiede all'utente di scegliere un corpo del quale chiedere informaizoni
		ss.stampaCorpi();
		
		int scelta = InputDati.leggiIntero("Scegli il corpo su cui richiedere informazioni: ", 0, 1+ss.getPianeti().size() + ss.getLune().size());
		ss.informazioni(scelta);
		InputDati.premiInvioPerContinuare();
	}
	
	
}
	
